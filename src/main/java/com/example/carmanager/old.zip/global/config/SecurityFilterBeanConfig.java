package com.example.carmanager.old.global.config;

import com.example.carmanager.old.global.filter.JsonLoginProcessFilter;
import com.example.carmanager.old.global.filter.JwtAuthorizationFilter;
import com.example.carmanager.old.global.filter.handler.JwtProviderHandler;
import com.example.carmanager.old.global.oauth2.util.TokenProvider;
import com.example.carmanager.v2.user.repository.UserRepository;
import com.example.carmanager.v2.user.repository.RefreshTokenRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;

@Configuration
@RequiredArgsConstructor
public class SecurityFilterBeanConfig {

    private final ObjectMapper objectMapper;
    private final AuthenticationManager authenticationManager;
    private final TokenProvider tokenProvider;
    private final UserRepository userRepository;
    private final RefreshTokenRepository refreshTokenRepository;


    @Bean
    public JsonLoginProcessFilter jsonLoginProcessFilter(JwtProviderHandler jwtProviderHandler) {
        JsonLoginProcessFilter jsonLoginProcessFilter = new JsonLoginProcessFilter(objectMapper, authenticationManager);
        jsonLoginProcessFilter.setAuthenticationSuccessHandler(jwtProviderHandler);
        return jsonLoginProcessFilter;
    }

    @Bean
    public JwtAuthorizationFilter jwtAuthorizationFilter() {
        return new JwtAuthorizationFilter(tokenProvider, userRepository, refreshTokenRepository);
    }

    @Bean
    public JwtProviderHandler jwtProviderHandler() {
        return new JwtProviderHandler(tokenProvider, userRepository);
    }
}