package com.example.carmanager.old.global.filter;

import com.example.carmanager.old.global.oauth2.util.TokenProvider;
import com.example.carmanager.v2.user.entity.CustomUser;
import com.example.carmanager.v2.user.entity.User;
import com.example.carmanager.v2.user.repository.RefreshTokenRepository;
import com.example.carmanager.v2.user.repository.UserRepository;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Optional;

@RequiredArgsConstructor
@Component
@Slf4j
public class JwtAuthorizationFilter extends OncePerRequestFilter {

    private final TokenProvider tokenProvider;
    private final UserRepository userRepository;
    private final RefreshTokenRepository refreshTokenRepository;

    /**
     * accessToken 유효 -> authentication 저장
     * accessToken 만료
     *      refreshToken 유효 -> authentication 저장, accessToken 갱신
     *      refreshToken 만료 -> authentication 저장 X
     */

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException, IOException {
        log.info("Request URI: {}", request.getRequestURI());

        // access_token을 Authorization 헤더에서 추출
        Optional<String> accessToken = extractAccessToken(request);
        Boolean vaild = tokenProvider.isTokenValid(String.valueOf(accessToken));
        accessToken.filter(tokenProvider::isTokenValid)
                .ifPresentOrElse(
                        this::saveAuthentication,
                        () -> checkRefreshToken(request, response)
                );

        filterChain.doFilter(request, response);
    }

    private Optional<String> extractAccessToken(HttpServletRequest request) {
        String authHeader = request.getHeader("Authorization");
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            return Optional.of(authHeader.substring(7)); // "Bearer " 다음 문자열 추출
        }
        return Optional.empty();
    }

    private void saveAuthentication(String accessToken) {
        String email = tokenProvider.extractUserEmail(accessToken);
        CustomUser securityUser = new CustomUser(userRepository.findUserByEmail(email).get());
        UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(securityUser, null, securityUser.getAuthorities());
        SecurityContextHolder.getContext().setAuthentication(authentication);
    }

    private void checkRefreshToken(HttpServletRequest request, HttpServletResponse response) {
        Optional<String> refreshToken = extractRefreshToken(request);
        Boolean vaild = tokenProvider.isTokenValid(String.valueOf(refreshToken));
        refreshToken.filter(tokenProvider::isTokenValid)
                .ifPresentOrElse(
                        token -> {
                            // refreshToken이 유효한 경우 처리
                            Long userId = refreshTokenRepository.findUserIdByRefreshToken(token);
                            User user = userRepository.findByUserId(userId);
                            String newAccessToken = tokenProvider.createAccessToken(user.getEmail());
                            tokenProvider.setAccessTokenInHeader(response, newAccessToken);
                            saveAuthentication(newAccessToken);
                        },
                        this::doNotSaveAuthentication
                );
    }

    private Optional<String> extractRefreshToken(HttpServletRequest request) {
        // 쿠키에서 refresh_token 추출
        String refreshToken = null;
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("refresh_token".equals(cookie.getName())) {
                    refreshToken = cookie.getValue();
                    break;
                }
            }
        }
        return Optional.ofNullable(refreshToken); // refresh_token이 null일 경우 Optional.empty() 반환
    }


    private void doNotSaveAuthentication() {
    }
}