package com.example.carmanager.user.dto;

import lombok.Data;

@Data
public class OAuthLoginRequest {
    private long id;
    private String username;
}
