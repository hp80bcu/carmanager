package com.example.carmanager.user.dto;

import lombok.Data;
import lombok.Setter;

@Data
public class UserFindIdResponse {
    String id;
}
