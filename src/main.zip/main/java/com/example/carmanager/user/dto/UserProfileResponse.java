package com.example.carmanager.user.dto;

import lombok.Data;

@Data
public class UserProfileResponse {
    Long userId;
    String name;
}
