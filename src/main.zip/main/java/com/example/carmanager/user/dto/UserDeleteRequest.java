package com.example.carmanager.user.dto;

import lombok.Data;

@Data
public class UserDeleteRequest {
    private String id;
}
